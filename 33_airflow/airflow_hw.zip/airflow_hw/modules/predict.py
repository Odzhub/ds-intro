import os
import glob
from datetime import datetime

import dill
import json
import pandas as pd
from pathlib import Path


path = os.environ.get('PROJECT_PATH', os.path.expanduser('~/airflow_hw'))


def predict():
    list_of_pred_models = glob.glob(f'{path}/data/models/*')
    latest_pred_model = max(list_of_pred_models, key=os.path.getctime)

    with open(latest_pred_model, 'rb') as file:
        model = dill.load(file)

    files_list = Path(f'{path}/data/test').glob('*.json')

    data = []
    for file_name in files_list:
        with open(file_name) as applicant:
            form = json.load(applicant)
            df = pd.DataFrame.from_dict([form])
            y = model.predict(df)
            result = (form["id"], y[0])
            data.append(result)
    prediction = pd.DataFrame(data, columns=['id', 'prediction'])
    print(prediction)

    prediction.to_csv(f'{path}/data/predictions/preds_{datetime.now().strftime("%Y%m%d%H%M")}.csv')


if __name__ == '__main__':
    predict()
